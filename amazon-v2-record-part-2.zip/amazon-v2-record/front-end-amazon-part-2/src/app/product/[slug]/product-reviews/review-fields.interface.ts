export interface IReviewFields {
	rating: number
	text: string
}
