export const RATING_VARIANTS = [1, 2, 3, 4, 5]
