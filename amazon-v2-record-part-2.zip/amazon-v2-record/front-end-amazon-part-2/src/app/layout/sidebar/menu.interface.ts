export interface IMenuItem {
	label: string
	href: string
}
