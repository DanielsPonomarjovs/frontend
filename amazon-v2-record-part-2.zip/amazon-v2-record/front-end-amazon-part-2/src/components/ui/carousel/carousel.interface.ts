export interface ICarouselItem {
	title: string
	description: string
	image?: string
	link?: string
}
