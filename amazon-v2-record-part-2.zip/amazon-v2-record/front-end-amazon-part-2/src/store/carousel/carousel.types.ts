export interface ICarouselInitialState {
	selectedItemIndex: number
}
