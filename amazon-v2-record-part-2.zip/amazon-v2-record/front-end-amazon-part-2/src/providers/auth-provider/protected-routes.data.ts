export const protectedRoutes = ['/my-orders', '/favorites']
