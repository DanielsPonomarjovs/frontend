export type TypeParamSlug = {
	slug?: string
}

export interface IPageSlugParam {
	params: TypeParamSlug
}
