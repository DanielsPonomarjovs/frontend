export const SITE_NAME = 'Amazon v2 by RED Group'

export const NO_INDEX_PAGE = { robots: { index: false, follow: false } }
